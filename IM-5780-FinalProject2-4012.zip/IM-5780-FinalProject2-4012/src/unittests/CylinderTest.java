package unittests;

import org.junit.Test;

import static org.junit.Assert.*;

public class CylinderTest {

    @Test
    public void getNormal() {
    }
}